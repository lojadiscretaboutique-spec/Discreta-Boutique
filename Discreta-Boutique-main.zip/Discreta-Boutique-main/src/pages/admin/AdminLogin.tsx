import { useState } from 'react';
import { signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth, db } from '../../lib/firebase';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { doc, getDoc } from 'firebase/firestore';
import { useAuthStore } from '../../store/authStore';
import { useFeedback } from '../../contexts/FeedbackContext';
import { useSettings } from '../../contexts/SettingsContext';

export function AdminLogin() {
  const settings = useSettings();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const checkAuth = useAuthStore(s => s.checkAuth);
  const { toast } = useFeedback();

  const handleResetPassword = async () => {
    if (!email) return setError('Informe seu e-mail para receber o link de recuperação.');
    try {
        await sendPasswordResetEmail(auth, email);
        toast("E-mail de recuperação enviado! Verifique sua caixa de entrada.", "success");
    } catch (err: any) {
        setError('Erro ao enviar e-mail: ' + err.message);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    const trimmedEmail = email.trim();
    if (!trimmedEmail || !password) {
      setError('Por favor, preencha o e-mail e a senha.');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, trimmedEmail, password);
      const user = userCredential.user;
      
      try {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        const userData = userDoc.data();
        
        if (!userDoc.exists() || userData?.status !== 'ativo') {
          await auth.signOut();
          setError('Acesso negado. Sua conta não está ativa ou não possui privilégios.');
          checkAuth();
        } else {
          // Check if user is only a Motoboy
          const roles = userData.roles || (userData.role ? [userData.role] : []);
          const isOnlyMotoboy = roles.length === 1 && (roles.includes('ROLE_MOTOBOY') || roles.includes('motoboy'));
          if (isOnlyMotoboy) {
            await auth.signOut();
            setError('Acesso negado. Entregadores / Motoboys devem fazer login exclusivamente no aplicativo de entregas (/motoboy/login).');
            checkAuth();
            return;
          }

          const perms = userData.computedPermissions || {};
          const hasAnyPerm = Object.values(perms).some((mod: any) => 
            Object.values(mod).some(val => val === true)
          );

          if (!hasAnyPerm && userData.role !== 'admin') {
            await auth.signOut();
            setError('Acesso negado. Você não possui permissões administrativas atribuídas.');
            checkAuth();
          } else {
            checkAuth();
            navigate('/admin');
          }
        }
      } catch {
        await auth.signOut();
        setError('Erro de permissão ao validar privilégios. Verifique seu cadastro no painel Firebase.');
        checkAuth();
      }
      
    } catch (err: unknown) {
      console.warn('Erro contornado no login:', err);
      let errorMessage = 'Falha na autenticação. Verifique suas credenciais.';
      if (err instanceof Error) {
        if (err.message.includes('auth/invalid-email')) {
          errorMessage = 'O formato do e-mail é inválido.';
        } else if (err.message.includes('auth/user-not-found') || err.message.includes('auth/wrong-password') || err.message.includes('auth/invalid-credential')) {
          errorMessage = 'E-mail ou senha incorretos.';
        } else if (err.message.includes('auth/too-many-requests')) {
          errorMessage = 'Muitas tentativas falhas. Tente novamente mais tarde.';
        } else if (err.message.includes('auth/operation-not-allowed')) {
          errorMessage = 'Autenticação por e-mail e senha desativada no Firebase console.';
        }
      }
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen w-full flex items-center justify-center bg-slate-950 px-4">
      <div className="max-w-md w-full bg-slate-900 rounded-xl shadow-xl border border-slate-800 overflow-hidden">
        <div className="bg-black py-8 text-center flex flex-col items-center gap-2">
          {settings.logoUrl ? (
            <img src={settings.logoUrl || undefined} alt={settings.storeName} className="h-16 w-auto object-contain mb-2" />
          ) : (
            <span className="text-red-600 font-black text-3xl tracking-tighter italic">DISCRETA</span>
          )}
          <span className="text-slate-400 font-bold text-[10px] tracking-[0.2em] uppercase">Painel de Gestão</span>
        </div>
        <form onSubmit={handleLogin} className="p-8 flex flex-col space-y-4">
          {error && <div className="p-3 bg-red-100 text-red-700 rounded-md text-sm">{error}</div>}
          
          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <Input 
              type="email" 
              required 
              value={email} 
              onChange={e => setEmail(e.target.value)} 
              placeholder="admin@discreta.com"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Senha</label>
            <Input 
              type="password" 
              required 
              value={password} 
              onChange={e => setPassword(e.target.value)} 
              placeholder="••••••••"
            />
            <div className="flex justify-end mt-1">
                <button 
                  type="button" 
                  onClick={handleResetPassword}
                  className="text-[10px] font-bold text-slate-400 hover:text-red-600 transition-colors uppercase tracking-wider"
                >
                    Esqueci minha senha
                </button>
            </div>
          </div>
          
          <Button type="submit" disabled={loading} className="w-full mt-2">
            {loading ? 'Entrando...' : 'Acessar Painel'}
          </Button>

          <Button type="button" variant="outline" onClick={() => navigate('/')} className="w-full">
            Voltar para a Loja
          </Button>
        </form>
      </div>
    </div>
  );
}
