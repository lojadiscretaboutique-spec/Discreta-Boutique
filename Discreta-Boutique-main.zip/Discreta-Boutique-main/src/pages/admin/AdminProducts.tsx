import { useEffect, useState, useCallback, useMemo } from 'react';
import { collection, getDocs, orderBy, query, doc, writeBatch, serverTimestamp, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { aiFrontendService } from '../../services/aiFrontendService';
import { 
  Plus, Edit2, Trash2, X, Upload, Save, ArrowLeft, 
  Info, DollarSign, Layers, Shirt, Droplets, Image as ImageIcon, 
  Search, Check, Sparkles, CheckSquare, Square, Eye, EyeOff, Package, PackageX,
  Filter, ChevronDown, ChevronUp, AlertCircle, Loader2
} from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { formatCurrency, cn } from '../../lib/utils';
import { productService, Product, ProductVariant } from '../../services/productService';
import { Category } from '../../services/categoryService';
import { PLACEHOLDER_IMAGE } from '../../lib/utils';
import { useFeedback } from '../../contexts/FeedbackContext';
import { useAuthStore } from '../../store/authStore';

// Sections IDs
type FormSection = 'general' | 'categories' | 'price' | 'variants' | 'fashion' | 'cosmetics' | 'images' | 'seo';

export function AdminProducts() {
  const { hasPermission } = useAuthStore();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'list' | 'form'>('list');
  const [activeTab, setActiveTab] = useState<FormSection>('general');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const { toast, confirm } = useFeedback();

  const canCreate = hasPermission('produtos', 'criar');
  const canEdit = hasPermission('produtos', 'editar');
  const canDelete = hasPermission('produtos', 'excluir');
  
  // Categories (to be loaded from DB)
  const [categories, setCategories] = useState<Category[]>([]);
  const [categorySearch, setCategorySearch] = useState('');
  const [categorySuggestions, setCategorySuggestions] = useState<{categoryId: string, confidence: number}[]>([]);

  const initialProduct: Omit<Product, 'id'> = {
    name: '',
    active: true,
    featured: false,
    newRelease: false,
    categoryId: '',
    categoryIds: [],
    sku: '',
    price: 0,
    stock: 0,
    unit: 'un',
    controlStock: true,
    allowBackorder: false,
    hasVariants: false,
    images: [],
    seo: { slug: '', condition: 'new' },
    extras: { showInCatalog: true }
  };

  const [form, setForm] = useState<Omit<Product, 'id'>>(initialProduct);
  const [variants, setVariants] = useState<ProductVariant[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [suggestedMultiplier, setSuggestedMultiplier] = useState(2.5);
  const [forceRegen, setForceRegen] = useState(false);

  // Categorization effect
  useEffect(() => {
    const timer = setTimeout(async () => {
      if ((form.name || form.fullDescription) && activeTab === 'categories') {
        const response = await fetch('/api/products/categorize', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            name: form.name, 
            description: form.fullDescription,
            brand: form.brand,
            tags: form.ai_keywords || []
          })
        });
        const data = await response.json();
        setCategorySuggestions(data.suggestions || []);
      }
    }, 1000);
    return () => clearTimeout(timer);
  }, [form.name, form.fullDescription, form.brand, form.ai_keywords, activeTab]);

  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    hasImage: 'all',
    stockStatus: 'all',
    categoryId: 'all',
    status: 'all',
    showInCatalog: 'all',
    featured: 'all',
    newRelease: 'all',
    hasVariants: 'all'
  });

  const clearFilters = () => {
    setFilters({
      hasImage: 'all',
      stockStatus: 'all',
      categoryId: 'all',
      status: 'all',
      showInCatalog: 'all',
      featured: 'all',
      newRelease: 'all',
      hasVariants: 'all'
    });
    setSearchTerm('');
  };

  // Auto-generation helpers
  const generateSlug = (name: string) => {
    return name.toLowerCase().trim()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // Remove accents
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
  };

  const generateSku = () => {
    const prefix = form.brand?.slice(0, 3).toUpperCase() || 'DB';
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `${prefix}-${rand}`;
  };

  const generateEan13 = () => {
    let ean = "789"; 
    for (let i = 0; i < 9; i++) ean += Math.floor(Math.random() * 10).toString();
    let sum = 0;
    for (let i = 0; i < 12; i++) sum += parseInt(ean[i]) * (i % 2 === 0 ? 1 : 3);
    return ean + ((10 - (sum % 10)) % 10).toString();
  };

  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
  const [isBulkCategoryModalOpen, setIsBulkCategoryModalOpen] = useState(false);
  const [bulkCategoryAction, setBulkCategoryAction] = useState<'add' | 'remove'>('add');
  const [bulkSelectedCategoryIds, setBulkSelectedCategoryIds] = useState<string[]>([]);
  const [bulkProgress, setBulkProgress] = useState({ total: 0, processed: 0, updated: 0, skipped: 0, logs: [] as string[] });
  const [isBulkRunning, setIsBulkRunning] = useState(false);
  
  // Single Product Category Management
  const [isSingleCategoryModalOpen, setIsSingleCategoryModalOpen] = useState(false);
  const [targetProduct, setTargetProduct] = useState<Product | null>(null);
  const [targetCategoryIds, setTargetCategoryIds] = useState<string[]>([]);

  const handleSingleCategoryUpdate = async () => {
    if (!targetProduct) return;
    setLoading(true);
    try {
      const ref = doc(db, 'products', targetProduct.id!);
      await writeBatch(db).update(ref, {
        categoryIds: targetCategoryIds,
        categoryId: targetCategoryIds[0] || '',
        updatedAt: serverTimestamp()
      }).commit();
      
      toast("Categorias atualizadas com sucesso!");
      setIsSingleCategoryModalOpen(false);
      loadData();
    } catch (e: any) {
      console.error(e);
      toast(`Erro ao atualizar categorias: ${e.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkCategory = async () => {
    if (selectedIds.length === 0 || bulkSelectedCategoryIds.length === 0) return;

    setIsBulkRunning(true);
    setBulkProgress({ total: selectedIds.length, processed: 0, updated: 0, skipped: 0, logs: ["Iniciando processamento em lote..."] });
    setIsBulkModalOpen(true);

    try {
        const CHUNK_SIZE = 450; // Safety margin for Firestore's 500 limit
        let processedCount = 0;

        for (let i = 0; i < selectedIds.length; i += CHUNK_SIZE) {
            const chunk = selectedIds.slice(i, i + CHUNK_SIZE);
            const batch = writeBatch(db);
            let updatedInBatch = 0;

            for (const id of chunk) {
                const product = products.find(p => p.id === id);
                if (!product) continue;

                const ref = doc(db, 'products', id);
                let currentCategoryIds = [...(product.categoryIds || [])];
                let changed = false;

                if (bulkCategoryAction === 'add') {
                    bulkSelectedCategoryIds.forEach(catId => {
                        if (!currentCategoryIds.includes(catId)) {
                            currentCategoryIds.push(catId);
                            changed = true;
                        }
                    });
                } else {
                    const originalLength = currentCategoryIds.length;
                    currentCategoryIds = currentCategoryIds.filter(id => !bulkSelectedCategoryIds.includes(id));
                    if (currentCategoryIds.length !== originalLength) changed = true;
                }

                if (changed) {
                    batch.update(ref, { 
                        categoryIds: currentCategoryIds,
                        categoryId: currentCategoryIds[0] || '', // Fallback for legacy compatibility
                        updatedAt: serverTimestamp() 
                    });
                    updatedInBatch++;
                }
            }

            if (updatedInBatch > 0) {
                await batch.commit();
            }

            processedCount += chunk.length;
            setBulkProgress(prev => ({
                ...prev,
                processed: processedCount,
                updated: prev.updated + updatedInBatch,
                logs: [`Processados ${processedCount} de ${selectedIds.length} produtos...`, ...prev.logs.slice(0, 10)]
            }));
        }

        toast(`Categorização concluída. ${selectedIds.length} produtos processados.`);
        setIsBulkCategoryModalOpen(false);
        setIsBulkModalOpen(false);
        setBulkSelectedCategoryIds([]);
        setSelectedIds([]);
        loadData();
    } catch (e: any) {
        console.error("Bulk categorization error:", e);
        toast(`Erro na categorização: ${e.message}`, 'error');
    } finally {
        setIsBulkRunning(false);
    }
  };

  const handleAIContent = async () => {
    const hasCategory = form.categoryId || (form.categoryIds && form.categoryIds.length > 0);
    if (!form.name || !hasCategory) {
      toast("Para gerar conteúdo, preencha o Nome e selecione ao menos uma Categoria primeiro.", 'warning');
      return;
    }

    setAiLoading(true);
    try {
      // Obter nomes de todas as categorias selecionadas para um prompt mais rico
      const selectedCatNames = (form.categoryIds && form.categoryIds.length > 0)
        ? categories.filter(c => form.categoryIds?.includes(c.id)).map(c => c.name)
        : [categories.find(c => c.id === form.categoryId)?.name || form.categoryId];
      
      // 1. Generate text content (descriptions, meta tags)
      const data = await aiFrontendService.generateProductContent(form.name, selectedCatNames, form.fullDescription);

      // 2. Enrich with SEO keywords and synonyms using OpenAI
      const enrichment = await aiFrontendService.enrichProduct(form.name, data.descricao_longa || form.fullDescription || '');

      // 3. Generate Embedding
      // Use the most complete text possible for better semantic search
      const combinedKeywords = [...new Set([...(data.palavras_chave || []), ...(enrichment.keywords || [])])];
      const combinedSynonyms = [...new Set([...(data.sinonimos || []), ...(enrichment.synonyms || [])])];
      const combinedSearchTerms = [...new Set([...(data.termos_busca || []), ...(enrichment.searchTerms || [])])];

      const embeddingText = `
        ${form.name} 
        ${data.titulo} 
        ${data.descricao_curta} 
        ${selectedCatNames.join(' ')}
        ${data.descricao_longa.replace(/<[^>]*>/g, '')} 
        ${combinedKeywords.join(' ')} 
        ${combinedSynonyms.join(' ')} 
        ${combinedSearchTerms.join(' ')}
      `.trim();
      
      const embedding = await aiFrontendService.generateEmbedding(embeddingText);

      setForm(prev => ({
        ...prev,
        subtitle: data.titulo || prev.subtitle,
        shortDescription: data.descricao_curta || prev.shortDescription,
        fullDescription: data.descricao_longa || prev.fullDescription,
        ai_keywords: combinedKeywords,
        ai_synonyms: combinedSynonyms,
        searchTerms: combinedSearchTerms,
        embedding: embedding,
        seo: {
          ...prev.seo!,
          metaTitle: data.meta_title || prev.seo?.metaTitle,
          metaDescription: data.meta_description || prev.seo?.metaDescription,
          keywords: combinedKeywords.length > 0 ? combinedKeywords : prev.seo?.keywords
        }
      }));

      toast("Conteúdo enriquecido com Inteligência Artificial com sucesso!", 'success');
    } catch (error: any) {
      console.error(error);
      toast(error.message || "Erro ao enriquecer conteúdo com IA.", 'error');
    } finally {
      setAiLoading(false);
    }
  };

  const handleBulkSEO = async () => {
    let targetIds = selectedIds;
    const isScan = targetIds.length === 0;

    if (isScan) {
      // Scan for products without SEO by intelligence:
      // - No metaTitle or no metaDescription
      // - Have min 1 image
      // - Active
      // - In stock (or has variants)
      const pending = products.filter(p => {
        const hasSEO = !!p.seo?.metaTitle && !!p.seo?.metaDescription && !!p.shortDescription;
        const hasRequirement = (p.images?.length || 0) > 0 && p.active && (p.stock > 0 || p.hasVariants || p.allowBackorder);
        return !hasSEO && hasRequirement;
      });
      targetIds = pending.map(p => p.id!);
      
      if (targetIds.length === 0) {
        toast("Nenhum produto pendente de SEO encontrado nos critérios (Ativo, com estoque e com imagem).", "info");
        return;
      }
    }

    const ok = await confirm({
      title: 'SEO Inteligente OpenAI',
      message: `Deseja processar ${targetIds.length} produtos? A IA irá gerar automaticamente Títulos, Descrições e Tags SEO. ${forceRegen ? "Modo Sobrescrever ATIVADO." : ""}`,
      confirmText: 'Iniciar Geração',
      variant: 'info'
    });

    if (!ok) return;

    setIsBulkRunning(true);
    setIsBulkModalOpen(true);
    setBulkProgress({ total: targetIds.length, processed: 0, updated: 0, skipped: 0, logs: ["Iniciando motor OpenAI..."] });

    for (let i = 0; i < targetIds.length; i++) {
        const id = targetIds[i];
        const p = products.find(prod => prod.id === id);
        if (!p) continue;

        // Double check SEO state if in scan mode and not forcing
        const hasSEO = !!p.seo?.metaTitle && !!p.seo?.metaDescription && !!p.shortDescription;
        if (hasSEO && !forceRegen && isScan) {
           setBulkProgress(prev => ({
             ...prev,
             processed: i + 1,
             skipped: prev.skipped + 1,
             logs: [`[PULADO] ${p.name}: Já possui SEO configurado.`, ...prev.logs.slice(0, 49)]
           }));
           continue;
        }

        try {
            // Get full details (for categories names)
            const detail = await productService.getProduct(id);
            if (!detail) throw new Error("Detalhes não encontrados");

            const { product, variants: productVariants } = detail;
            const selectedCatNames = (product.categoryIds && product.categoryIds.length > 0)
              ? categories.filter(c => product.categoryIds?.includes(c.id)).map(c => c.name)
              : [categories.find(c => c.id === product.categoryId)?.name || 'Geral'];

            // 1. Generate Content
            const data = await aiFrontendService.generateProductContent(product.name, selectedCatNames, product.fullDescription);
            
            // 2. Enrich
            const enrichment = await aiFrontendService.enrichProduct(product.name, data.descricao_longa || product.fullDescription || '');

            const combinedKeywords = [...new Set([...(data.palavras_chave || []), ...(enrichment.keywords || [])])];
            const combinedSynonyms = [...new Set([...(data.sinonimos || []), ...(enrichment.synonyms || [])])];
            const combinedSearchTerms = [...new Set([...(data.termos_busca || []), ...(enrichment.searchTerms || [])])];

            const embeddingText = `
              ${product.name} 
              ${data.titulo} 
              ${data.descricao_curta} 
              ${selectedCatNames.join(' ')}
              ${(data.descricao_longa || '').replace(/<[^>]*>/g, '')} 
              ${combinedKeywords.join(' ')} 
              ${combinedSynonyms.join(' ')} 
              ${combinedSearchTerms.join(' ')}
            `.trim();
            
            const embedding = await aiFrontendService.generateEmbedding(embeddingText);

            // 3. Update
            const updatedProduct: Partial<Product> = {
              subtitle: data.titulo || product.subtitle,
              shortDescription: data.descricao_curta || product.shortDescription,
              fullDescription: data.descricao_longa || product.fullDescription,
              ai_keywords: combinedKeywords,
              ai_synonyms: combinedSynonyms,
              searchTerms: combinedSearchTerms,
              embedding: embedding,
              seo: {
                ...(product.seo || { slug: generateSlug(product.name), condition: 'new' as const }),
                metaTitle: data.meta_title || product.seo?.metaTitle,
                metaDescription: data.meta_description || product.seo?.metaDescription,
                keywords: combinedKeywords
              }
            };

            await productService.updateProduct(id, updatedProduct, productVariants);

            setBulkProgress(prev => ({
              ...prev,
              processed: i + 1,
              updated: prev.updated + 1,
              logs: [`[SUCESSO] ${p.name}: SEO e Conteúdo atualizados.`, ...prev.logs.slice(0, 49)]
            }));

            // Rate limit safety
            await new Promise(resolve => setTimeout(resolve, 600));
        } catch (err: any) {
            setBulkProgress(prev => ({
              ...prev,
              processed: i + 1,
              logs: [`[ERRO] ${p.name}: ${err.message || 'Erro desconhecido'}`, ...prev.logs.slice(0, 49)]
            }));
        }
    }

    setIsBulkRunning(false);
    toast("Processamento de SEO em massa concluído!", 'success');
    loadData();
  };


  const handleBulkAction = async (action: 'delete' | 'activate' | 'deactivate' | 'showInCatalog' | 'hideFromCatalog' | 'addToFeatured' | 'removeFromFeatured' | 'addToNewRelease' | 'removeFromNewRelease') => {
    if (selectedIds.length === 0) return;

    let message = '';
    let confirmTitle = '';
    let confirmText = '';
    let variant: 'default' | 'danger' | 'warning' | 'info' | 'success' = 'default';

    switch (action) {
      case 'delete':
        confirmTitle = 'Excluir Selecionados';
        message = `Tem certeza que deseja excluir ${selectedIds.length} produtos? Esta ação não pode ser desfeita.`;
        confirmText = 'Excluir';
        variant = 'danger';
        break;
      case 'activate':
        confirmTitle = 'Tornar Ativos';
        message = `Deseja tornar ${selectedIds.length} produtos ativos?`;
        confirmText = 'Confirmar';
        break;
      case 'deactivate':
        confirmTitle = 'Tornar Indisponíveis';
        message = `Deseja tornar ${selectedIds.length} produtos indisponíveis (Inativos)?`;
        confirmText = 'Confirmar';
        break;
      case 'showInCatalog':
        confirmTitle = 'Exibir no Catálogo';
        message = `Deseja exibir ${selectedIds.length} produtos no catálogo do site?`;
        confirmText = 'Confirmar';
        break;
      case 'hideFromCatalog':
        confirmTitle = 'Ocultar do Catálogo';
        message = `Deseja ocultar ${selectedIds.length} produtos do catálogo do site?`;
        confirmText = 'Confirmar';
        break;
      case 'addToFeatured':
        confirmTitle = 'Definir como Destaque';
        message = `Deseja definir ${selectedIds.length} produtos como Destaque?`;
        confirmText = 'Confirmar';
        break;
      case 'removeFromFeatured':
        confirmTitle = 'Remover Destaque';
        message = `Deseja remover ${selectedIds.length} produtos dos Destaques?`;
        confirmText = 'Confirmar';
        break;
      case 'addToNewRelease':
        confirmTitle = 'Definir como Lançamento';
        message = `Deseja definir ${selectedIds.length} produtos como Lançamento?`;
        confirmText = 'Confirmar';
        break;
      case 'removeFromNewRelease':
        confirmTitle = 'Remover Lançamento';
        message = `Deseja remover ${selectedIds.length} produtos dos Lançamentos?`;
        confirmText = 'Confirmar';
        break;
    }

    const ok = await confirm({
      title: confirmTitle,
      message,
      confirmText,
      variant
    });

    if (!ok) return;

    setLoading(true);
    try {
      if (action === 'delete') {
        // Bulk delete one by one to handle variants correctly as in service
        // (Batch would be more complex due to variants subcollection)
        for (const id of selectedIds) {
          await productService.deleteProduct(id);
        }
        toast(`${selectedIds.length} produtos excluídos com sucesso!`);
      } else {
        const batch = writeBatch(db);
        selectedIds.forEach(id => {
          const ref = doc(db, 'products', id);
          const updateData: any = { updatedAt: serverTimestamp() };
          
          if (action === 'activate') updateData.active = true;
          if (action === 'deactivate') updateData.active = false;
          if (action === 'showInCatalog') updateData['extras.showInCatalog'] = true;
          if (action === 'hideFromCatalog') updateData['extras.showInCatalog'] = false;
          if (action === 'addToFeatured') updateData.featured = true;
          if (action === 'removeFromFeatured') updateData.featured = false;
          if (action === 'addToNewRelease') updateData.newRelease = true;
          if (action === 'removeFromNewRelease') updateData.newRelease = false;
          
          batch.update(ref, updateData);
        });
        await batch.commit();
        toast(`${selectedIds.length} produtos atualizados com sucesso!`);
      }
      setSelectedIds([]);
      loadData();
    } catch (error) {
      console.error(error);
      toast("Erro ao realizar ação em lote.", 'error');
    } finally {
      setLoading(false);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === currentProducts.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(currentProducts.map(p => p.id!));
    }
  };

  const toggleSelect = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const loadData = useCallback(() => {
    // No-op because we listen to Firestore onSnapshot live!
  }, []);

  useEffect(() => {
    setLoading(true);
    const qProd = query(collection(db, 'products'), orderBy('updatedAt', 'desc'));
    const unsubscribeProducts = onSnapshot(qProd, (snapshot) => {
      const productsData = snapshot.docs.map(doc => {
        const data = doc.data();
        if (data.images && Array.isArray(data.images)) {
          data.images.sort((a, b) => (b.isMain ? 1 : 0) - (a.isMain ? 1 : 0));
        }
        return { id: doc.id, ...data } as Product;
      });
      setProducts(productsData);
      setLoading(false);
    }, (error) => {
      console.error("Error listening to products:", error);
      setLoading(false);
    });

    const qCats = query(collection(db, 'categories'), orderBy('sortOrder', 'asc'));
    const unsubscribeCategories = onSnapshot(qCats, (snapshot) => {
      const categoriesData = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Category));
      setCategories(categoriesData);
    }, (error) => {
      console.error("Error listening to categories:", error);
    });

    return () => {
      unsubscribeProducts();
      unsubscribeCategories();
    };
  }, []);

  const handleEdit = async (prod: Product) => {
    setLoading(true);
    try {
      const detail = await productService.getProduct(prod.id!);
      if (detail) {
        // Ensure structure for nested objects
        const p = detail.product;
        setForm({
          ...p,
          categoryIds: p.categoryIds || (p.categoryId ? [p.categoryId] : []),
          fashion: p.fashion || {},
          cosmetics: p.cosmetics || {},
          seo: p.seo || { slug: generateSlug(p.name), condition: 'new' },
          extras: p.extras || { showInCatalog: true },
        });
        setVariants(detail.variants);
        setEditingId(prod.id!);
        setSuggestedMultiplier(2.5);
        setView('form');
        setActiveTab('general');
      }
    } catch (error: unknown) {
      console.error(error);
      const err = error as { code?: string };
      if (err?.code === 'permission-denied') {
        toast("Você não tem permissão para visualizar os detalhes deste produto.", 'error');
      } else {
        toast("Erro ao carregar detalhes do produto.", 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleNew = () => {
    setForm(initialProduct);
    setVariants([]);
    setEditingId(null);
    setSuggestedMultiplier(2.5);
    setView('form');
    setActiveTab('general');
  };

  const handleDelete = async (id: string, name: string) => {
    const ok = await confirm({
      title: 'Excluir Produto',
      message: `Tem certeza que deseja excluir "${name}"? Esta ação não pode ser desfeita.`,
      confirmText: 'Excluir',
      variant: 'danger'
    });

    if (ok) {
      try {
        await productService.deleteProduct(id);
        loadData();
        toast("Produto excluído com sucesso!");
      } catch {
        toast("Erro ao excluir produto.", 'error');
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Ensure all variants have barcode if not provided
    const finalVariants = variants.map(v => ({
      ...v,
      barcode: v.barcode || generateEan13(),
      sku: v.sku || generateSku()
    }));

    const hasCategory = form.categoryId || (form.categoryIds && form.categoryIds.length > 0);
    if (!form.name || !hasCategory || form.price <= 0) {
      toast("Por favor, preencha os campos obrigatórios (Nome, Categoria e Preço).", 'warning');
      return;
    }

    setSubmitting(true);
    // Check EAN uniqueness
    const checkMainBarcode = form.hasVariants ? null : (form.gtin || generateEan13());
    const barcodesToCheck = finalVariants.map(v => v.barcode).filter(Boolean);
    if (checkMainBarcode) barcodesToCheck.push(checkMainBarcode);

    if (barcodesToCheck.length > 0) {
      if (new Set(barcodesToCheck).size !== barcodesToCheck.length) {
        toast("Erro: Você tem Códigos de Barras (EAN) duplicados nas variações.", 'error');
        setSubmitting(false);
        return;
      }
      const gtinPromises = barcodesToCheck.map(b => productService.checkGtinExists(b as string, editingId || undefined));
      const gtinResults = await Promise.all(gtinPromises);
      if (gtinResults.some(r => r)) {
        toast("Erro: Um dos Códigos de Barras (EAN) já está em uso por outro produto ou variação.", 'error');
        setSubmitting(false);
        return;
      }
    }

    try {
      let currentForm = { ...form };

      // Auto generate AI content if SEO is missing
      if (!currentForm.seo?.metaTitle || !currentForm.seo?.metaDescription) {
        toast("Gerando SEO com Inteligência Artificial automaticamente...", 'info');
        try {
          const selectedCatNames = (currentForm.categoryIds && currentForm.categoryIds.length > 0)
            ? categories.filter(c => currentForm.categoryIds?.includes(c.id)).map(c => c.name)
            : [categories.find(c => c.id === currentForm.categoryId)?.name || currentForm.categoryId];
          
          const data = await aiFrontendService.generateProductContent(currentForm.name, selectedCatNames, currentForm.fullDescription);
          const enrichment = await aiFrontendService.enrichProduct(currentForm.name, data.descricao_longa || currentForm.fullDescription || '');

          const combinedKeywords = [...new Set([...(data.palavras_chave || []), ...(enrichment.keywords || [])])];
          const combinedSynonyms = [...new Set([...(data.sinonimos || []), ...(enrichment.synonyms || [])])];
          const combinedSearchTerms = [...new Set([...(data.termos_busca || []), ...(enrichment.searchTerms || [])])];

          const embeddingText = `
            ${currentForm.name} 
            ${data.titulo} 
            ${data.descricao_curta} 
            ${selectedCatNames.join(' ')}
            ${data.descricao_longa.replace(/<[^>]*>/g, '')} 
            ${combinedKeywords.join(' ')} 
            ${combinedSynonyms.join(' ')} 
            ${combinedSearchTerms.join(' ')}
          `.trim();
          
          const embedding = await aiFrontendService.generateEmbedding(embeddingText);

          currentForm = {
            ...currentForm,
            subtitle: data.titulo || currentForm.subtitle,
            shortDescription: data.descricao_curta || currentForm.shortDescription,
            fullDescription: data.descricao_longa || currentForm.fullDescription,
            ai_keywords: combinedKeywords,
            ai_synonyms: combinedSynonyms,
            searchTerms: combinedSearchTerms,
            embedding: embedding,
            seo: {
              ...currentForm.seo!,
              metaTitle: data.meta_title || currentForm.seo?.metaTitle,
              metaDescription: data.meta_description || currentForm.seo?.metaDescription,
              keywords: combinedKeywords.length > 0 ? combinedKeywords : currentForm.seo?.keywords
            }
          };
        } catch (error) {
          console.error("Erro na geração de IA automática:", error);
          toast("Não foi possível gerar SEO automático. Salvando com os dados atuais.", "warning");
        }
      }

      const finalForm = {
        ...currentForm,
        sku: currentForm.sku || generateSku(),
        gtin: currentForm.hasVariants ? '' : (currentForm.gtin || generateEan13()),
        searchTerms: currentForm.hasVariants ? finalVariants.map(v => `${v.name} ${v.barcode} ${v.sku}`.toLowerCase()) : (currentForm.searchTerms || []),
        variantIdentifiers: currentForm.hasVariants ? finalVariants.flatMap(v => [v.barcode, v.sku]).filter(Boolean) : [],
        extras: {
          ...currentForm.extras,
          showInCatalog: currentForm.images.length > 0 ? (currentForm.extras?.showInCatalog !== false) : false
        },
        seo: {
          ...currentForm.seo!,
          slug: currentForm.seo?.slug || generateSlug(currentForm.name)
        }
      };

      if (editingId) {
        await productService.updateProduct(editingId, finalForm, finalVariants);
      } else {
        await productService.createProduct(finalForm, finalVariants);
      }
      
      setView('list');
      loadData();
      toast(editingId ? "Produto atualizado com sucesso!" : "Produto cadastrado com sucesso!", 'success');
    } catch (err: unknown) {
      console.error(err);
      toast("Erro ao salvar produto.", 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    
    setUploading(true);
    try {
      const files = Array.from(e.target.files);
      const newImages = [...form.images];
      
      const processImage = (file: File): Promise<Blob> => {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (event) => {
            const img = new Image();
            img.onload = () => {
              const canvas = document.createElement('canvas');
              const MAX_WIDTH = 1080;
              const MAX_HEIGHT = 1080;
              let width = img.width;
              let height = img.height;

              if (width > height) {
                if (width > MAX_WIDTH) {
                  height *= MAX_WIDTH / width;
                  width = MAX_WIDTH;
                }
              } else {
                if (height > MAX_HEIGHT) {
                  width *= MAX_HEIGHT / height;
                  height = MAX_HEIGHT;
                }
              }

              canvas.width = width;
              canvas.height = height;
              const ctx = canvas.getContext('2d');
              ctx?.drawImage(img, 0, 0, width, height);

              canvas.toBlob((blob) => {
                if (blob) resolve(blob);
                else reject(new Error("Canvas to Blob failed"));
              }, 'image/webp', 0.85); // 85% quality WEBP
            };
            img.onerror = reject;
            if (typeof event.target?.result === 'string') {
              img.src = event.target.result;
            }
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      };

      for (const file of files) {
        const processedBlob = await processImage(file);
        const processedFile = new File([processedBlob], file.name.replace(/\.[^/.]+$/, "") + ".webp", { type: 'image/webp' });
        
        const result = await productService.uploadImage(processedFile);
        newImages.push({
          url: result.url,
          path: result.path,
          isMain: newImages.length === 0
        });
      }
      
      setForm({ ...form, images: newImages });
    } catch {
      alert("Erro no upload de imagem.");
    } finally {
      setUploading(false);
    }
  };

  const removeImage = async (index: number) => {
    const img = form.images[index];
    if (window.confirm("Deseja remover esta imagem?")) {
      await productService.deleteImage(img.path);
      const newImages = form.images.filter((_, i) => i !== index);
      // If we removed the main image, set current first as main
      if (img.isMain && newImages.length > 0) {
        newImages[0].isMain = true;
      }
      setForm({ ...form, images: newImages });
    }
  };

  const setMainImage = (index: number) => {
    const newImages = form.images.map((img, i) => ({
      ...img,
      isMain: i === index
    }));
    setForm({ ...form, images: newImages });
  };

  // Attribute Generator logic
  const [attrInput, setAttrInput] = useState({ name: '', values: '' });
  const [tempAttrs, setTempAttrs] = useState<{name: string, values: string[]}[]>([]);

  const addAttribute = () => {
    if (!attrInput.name || !attrInput.values) return;
    setTempAttrs([...tempAttrs, { 
      name: attrInput.name, 
      values: attrInput.values.split(',').map(v => v.trim()).filter(v => v) 
    }]);
    setAttrInput({ name: '', values: '' });
  };

  const generateVariants = () => {
    if (tempAttrs.length === 0) return;

    const cartesian = <T,>(...args: T[][]): T[][] => args.reduce((a, b) => a.flatMap(d => b.map(e => [d, e].flat() as T[]))) as T[][];
    const combinations = cartesian(...tempAttrs.map(a => a.values));
    
    const newVariants: ProductVariant[] = combinations.map((combo: string[] | string, index: number) => {
      const comboArr = Array.isArray(combo) ? combo : [combo];
      const name = comboArr.join(', ');
      const attrs: Record<string, string> = {};
      tempAttrs.forEach((a, i) => {
        attrs[a.name] = comboArr[i];
      });

      return {
        name: name,
        sku: `${form.sku || 'SKU'}-${name.replace(/[\s,]+/g, '-').toUpperCase()}-${index+1}`,
        barcode: generateEan13(),
        stock: 0,
        price: form.price,
        active: true,
        attributes: attrs
      };
    });

    setVariants([...variants, ...newVariants]);
    setForm({ ...form, hasVariants: true });
    setTempAttrs([]);
  };

  const groupedCategories = useMemo(() => {
    const roots = categories.filter(c => !c.parentId);
    const search = categorySearch.toLowerCase();
    
    return roots.map(root => {
      const children = categories.filter(c => c.parentId === root.id);
      const matchingChildren = children.filter(c => c.name.toLowerCase().includes(search));
      const rootMatches = root.name.toLowerCase().includes(search);
      
      if (!rootMatches && matchingChildren.length === 0) return null;
      
      return {
        ...root,
        rootMatches,
        matchingChildren: matchingChildren.length > 0 ? matchingChildren : [],
        allChildren: children
      };
    }).filter(Boolean);
  }, [categories, categorySearch]);

  const tabs: {id: FormSection, label: string, icon: React.ElementType}[] = [
    { id: 'general', label: 'Geral', icon: Info },
    { id: 'categories', label: 'Categorias', icon: Layers },
    { id: 'price', label: 'Preço/Estoque', icon: DollarSign },
    { id: 'variants', label: 'Variações', icon: Layers },
    ...(form.categoryId === 'moda' || form.categoryId === 'lingerie' || form.fashion?.pieceType ? [{ id: 'fashion' as FormSection, label: 'Moda', icon: Shirt }] : []),
    ...(form.categoryId === 'cosmeticos' || form.cosmetics?.type ? [{ id: 'cosmetics' as FormSection, label: 'Cosméticos', icon: Droplets }] : []),
    { id: 'images', label: 'Imagens', icon: ImageIcon },
    { id: 'seo', label: 'SEO', icon: Search },
  ];

  if (view === 'form') {
    return (
      <div className="flex flex-col gap-6 max-w-5xl mx-auto pb-20">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 sticky top-0 md:relative z-30 bg-slate-950 py-2">
          <div className="flex items-center gap-4">
            <button onClick={() => setView('list')} className="p-2 hover:bg-slate-900 rounded-full transition-colors">
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white">{editingId ? 'Editar Produto' : 'Novo Produto'}</h1>
              <p className="text-xs text-slate-400 uppercase font-bold tracking-wider">{form.name || 'Sem nome'}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => setView('list')}>Cancelar</Button>
            <Button onClick={handleSave} disabled={submitting}>
              {submitting ? 'Salvando...' : <><Save size={18} className="mr-2"/> Salvar Produto</>}
            </Button>
          </div>
        </header>

        <div className="bg-slate-900 rounded-2xl shadow-sm border border-slate-700 overflow-hidden flex flex-col md:flex-row h-[calc(100vh-120px)]">
          {/* Internal Navigation (Desktop Sidebar) */}
          <div className="w-full md:w-64 border-r bg-slate-800 flex flex-col pt-4 overflow-y-auto">
             {tabs.map(tab => {
               const Icon = tab.icon;
               return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "flex items-center gap-3 px-6 py-4 text-sm font-medium transition-all text-left",
                      activeTab === tab.id 
                        ? "bg-slate-900 text-red-600 border-r-2 border-red-600 shadow-sm" 
                        : "text-slate-400 hover:bg-slate-950"
                    )}
                  >
                    <Icon size={18} />
                    {tab.label}
                  </button>
               )
             })}
          </div>

          <div className="flex-1 p-6 md:p-8 overflow-y-auto w-full">
            {/* 1. GERAL */}
            {activeTab === 'general' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <h3 className="text-lg font-bold border-b pb-2">Informações Gerais</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-sm font-bold">Nome do Produto *</label>
                      <button 
                        type="button"
                        onClick={handleAIContent}
                        disabled={aiLoading || !form.name || !form.categoryId}
                        className={cn(
                          "flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-black uppercase tracking-wider transition-all",
                          aiLoading ? "bg-slate-800 text-slate-500" : "bg-red-600/10 text-red-500 hover:bg-red-600 hover:text-white"
                        )}
                      >
                        <Sparkles size={12} className={aiLoading ? "animate-pulse" : ""} />
                        {aiLoading ? 'Gerando...' : 'Gerar com IA'}
                      </button>
                    </div>
                    <Input value={form.name || ''} onChange={e => {
                      const name = e.target.value;
                      setForm({ ...form, name, seo: { ...form.seo!, slug: generateSlug(name), metaTitle: name } });
                    }} placeholder="Ex: Sutiã Renda Luxo" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-bold mb-1">Subtítulo / Chamada Curta</label>
                    <Input value={form.subtitle || ''} onChange={e => setForm({ ...form, subtitle: e.target.value })} placeholder="Ex: O toque de elegância que você merece" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-bold mb-1">Marca / Fabricante</label>
                    <Input value={form.brand || ''} onChange={e => setForm({ ...form, brand: e.target.value })} placeholder="Ex: Discreta Boutique" />
                  </div>
                </div>

                <div>
                   <label className="block text-sm font-bold mb-1">Descrição Curta</label>
                   <textarea 
                     className="w-full min-h-[80px] p-3 rounded-md border border-slate-600 bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                     value={form.shortDescription || ''}
                     onChange={e => setForm({ ...form, shortDescription: e.target.value, seo: { ...form.seo!, metaDescription: e.target.value } })}
                   />
                </div>

                <div>
                   <label className="block text-sm font-bold mb-1">Descrição Completa</label>
                   <textarea 
                     className="w-full min-h-[200px] p-3 rounded-md border border-slate-600 bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                     value={form.fullDescription || ''}
                     onChange={e => {
                       const val = e.target.value;
                       setForm({ 
                         ...form, 
                         fullDescription: val, 
                         seo: { 
                           ...form.seo!, 
                           metaDescription: form.shortDescription ? form.seo?.metaDescription : val.substring(0, 160) 
                         } 
                       });
                     }}
                     placeholder="Detalhes técnicos, benefícios e diferenciais..."
                   />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                   <div className="flex items-center gap-2 bg-slate-800 p-3 rounded-lg border border-slate-700">
                     <input type="checkbox" id="active" checked={form.active} onChange={e => setForm({...form, active: e.target.checked})} className="w-4 h-4 text-red-600 rounded" />
                     <label htmlFor="active" className="text-sm font-bold">Produto Ativo</label>
                   </div>
                   <div className="flex items-center gap-2 bg-slate-800 p-3 rounded-lg border border-slate-700">
                     <input 
                       type="checkbox" 
                       id="showInCatalog" 
                       checked={(form.extras?.showInCatalog !== false) && form.images.length > 0} 
                       onChange={e => setForm({...form, extras: {...form.extras, showInCatalog: e.target.checked}})} 
                       disabled={form.images.length === 0}
                       className="w-4 h-4 text-red-600 rounded disabled:opacity-50" 
                     />
                     <label htmlFor="showInCatalog" className={cn("text-sm font-bold whitespace-nowrap", form.images.length === 0 && "text-slate-500")} title={form.images.length === 0 ? "Requer imagens" : ""}>Exibir Catálogo</label>
                   </div>
                   <div className="flex items-center gap-2 bg-slate-800 p-3 rounded-lg border border-slate-700">
                     <input type="checkbox" id="featured" checked={form.featured} onChange={e => setForm({...form, featured: e.target.checked})} className="w-4 h-4 text-red-600 rounded" />
                     <label htmlFor="featured" className="text-sm font-bold">Destaque</label>
                   </div>
                   <div className="flex items-center gap-2 bg-slate-800 p-3 rounded-lg border border-slate-700">
                     <input type="checkbox" id="newRelease" checked={form.newRelease} onChange={e => setForm({...form, newRelease: e.target.checked})} className="w-4 h-4 text-red-600 rounded" />
                     <label htmlFor="newRelease" className="text-sm font-bold">Lançamento</label>
                   </div>
                </div>
              </div>
            )}

            {/* Categorias Tab */}
            {activeTab === 'categories' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <h3 className="text-lg font-bold border-b pb-2">Seleção de Categorias</h3>
                
                {/* SUGGESTÕES INTELIGENTES */}
                <div className="p-4 bg-slate-900 border border-red-600/30 rounded-xl">
                  <h4 className="text-sm font-bold text-red-500 mb-3 flex items-center gap-2">
                    <Sparkles size={16} /> Sugestões Inteligentes (IA)
                  </h4>
                  {aiLoading ? (
                    <div className="py-2 text-xs text-slate-500 flex items-center gap-2 animate-pulse">
                      <Loader2 size={14} className="animate-spin" /> Analisando semântica do produto...
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                       { ( (form.name || form.fullDescription) && (categories.length > 0) ) ? (
                         <>
                          {categorySuggestions.map(s => {
                              const cat = categories.find(c => c.id === s.categoryId);
                              if (!cat || form.categoryIds?.includes(cat.id)) return null;
                              return (
                                <button
                                  key={cat.id}
                                  type="button"
                                  onClick={() => {
                                      const currentIds = form.categoryIds || [];
                                      setForm({ 
                                        ...form, 
                                        categoryIds: [...currentIds, cat.id],
                                        categoryId: currentIds[0] || cat.id
                                      });
                                  }}
                                  className="px-2 py-1 bg-red-950 text-red-300 rounded text-[10px] uppercase font-bold hover:bg-red-800"
                                >
                                  + {cat.name}
                                </button>
                              );
                          })}
                         </>
                       ) : <p className="text-xs text-slate-500 italic">Preencha nome/descrição para IA sugerir.</p>}
                    </div>
                  )}
                </div>
                
                <div className="flex flex-col">
                  <label className="block text-sm font-bold mb-3 flex items-center gap-2 px-1">
                     <Layers size={16} className="text-red-500" />
                     Categorias e Filtros
                  </label>
                  <p className="text-xs text-slate-400 mb-4 px-1">
                    Associe o produto a quantas categorias forem necessárias. Categorias definem a organização no catálogo.
                  </p>
                  <div className="mb-4 relative">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Pesquisar categoria..."
                      value={categorySearch}
                      onChange={(e) => setCategorySearch(e.target.value)}
                      className="w-full pl-9 pr-3 py-3 bg-slate-900 border border-slate-700 rounded-lg text-sm focus:ring-1 focus:ring-red-500 outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-4 p-4 bg-slate-900/50 rounded-xl border border-slate-800">
                     {groupedCategories.map((root: any) => {
                       const search = categorySearch.toLowerCase();
                       return (
                         <div key={root.id} className="space-y-3 pb-4 last:pb-0 border-b border-slate-800 last:border-0 hover:border-slate-700">
                           <p className="text-[11px] font-black uppercase text-slate-400 tracking-wider sticky top-0 bg-slate-900/80 p-2 rounded">{root.name}</p>
                           <div className="flex flex-wrap gap-2">
                             {[root, ...root.allChildren].map((c: any) => {
                               if (search && !c.name.toLowerCase().includes(search)) return null;
                               
                               const isSelected = form.categoryIds?.includes(c.id);
                               return (
                                 <button
                                   key={c.id}
                                   type="button"
                                   onClick={() => {
                                     const currentIds = form.categoryIds || [];
                                     const newIds = isSelected 
                                       ? currentIds.filter(id => id !== c.id)
                                       : [...currentIds, c.id];
                                     
                                     setForm({ 
                                       ...form, 
                                       categoryIds: newIds,
                                       categoryId: newIds[0] || ''
                                     });
                                   }}
                                   className={cn(
                                     "px-4 py-2 rounded-full text-xs font-bold transition-all border",
                                     isSelected 
                                       ? "bg-red-600 text-white border-red-500 shadow-md ring-2 ring-red-500/20" 
                                       : "bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-500"
                                   )}
                                 >
                                   {c.name}
                                 </button>
                               );
                             })}
                           </div>
                         </div>
                       );
                     })}
                  </div>
                  {(!form.categoryIds || form.categoryIds.length === 0) && (
                    <p className="text-[11px] text-red-500 mt-2 font-bold animate-pulse px-1">(!) Selecione ao menos uma categoria para o produto.</p>
                  )}
                </div>
              </div>
            )}

            {/* 2. PREÇO E ESTOQUE */}
            {activeTab === 'price' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <h3 className="text-lg font-bold border-b pb-2">Preço e Estoque</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-bold mb-1">Preço de Custo (R$)</label>
                    <Input type="number" step="0.01" value={form.costPrice ?? 0} onChange={e => setForm({...form, costPrice: Number(e.target.value)})} />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-1 text-red-600">Preço de Venda (R$) *</label>
                    <Input type="number" step="0.01" value={form.price ?? 0} onChange={e => setForm({...form, price: Number(e.target.value)})} />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-1">Preço Promocional (R$)</label>
                    <Input type="number" step="0.01" value={form.promoPrice ?? 0} onChange={e => setForm({...form, promoPrice: Number(e.target.value)})} />
                  </div>
                </div>

                <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 flex flex-col md:flex-row gap-4 justify-between items-center">
                   <div>
                     <p className="text-sm font-bold text-slate-200">Margem de Lucro</p>
                     <p className="text-2xl font-black text-green-600">
                       {form.price && form.costPrice ? `${(((form.price - form.costPrice) / form.price) * 100).toFixed(1)}%` : '---'}
                     </p>
                   </div>
                   <div className="w-px h-10 bg-slate-700 hidden md:block"></div>
                   <div className="flex-1">
                     <p className="text-xs text-slate-400 mb-1">Lucro por Unidade</p>
                     <p className="font-bold text-white">{form.price && form.costPrice ? formatCurrency(form.price - form.costPrice) : '---'}</p>
                   </div>
                   <div className="w-px h-10 bg-slate-700 hidden md:block"></div>
                   <div className="text-right flex flex-col items-end">
                     <p className="text-xs text-slate-400 mb-1 flex items-center gap-1">
                       Valor Sugerido (x 
                       <input 
                         type="number" 
                         step="0.1" 
                         min="1"
                         className="w-12 bg-slate-900 border border-slate-600 rounded px-1 py-0.5 text-center text-white" 
                         value={suggestedMultiplier} 
                         onChange={e => setSuggestedMultiplier(Number(e.target.value) || 2.5)} 
                       />
                       )
                     </p>
                     <p className="text-lg font-black text-blue-400">{form.costPrice ? formatCurrency(form.costPrice * suggestedMultiplier) : '---'}</p>
                   </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   <div>
                     <label className="block text-sm font-bold mb-1">SKU Principal</label>
                     <div className="relative">
                        <Input value={form.sku || ''} onChange={e => setForm({...form, sku: e.target.value})} placeholder="Gerado automaticamente" />
                        <button type="button" onClick={() => setForm({...form, sku: generateSku()})} className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-bold text-red-600">AUTO</button>
                     </div>
                   </div>
                   <div>
                     <label className="block text-sm font-bold mb-1">EAN / Código de Barras {(!form.hasVariants) && <span className="text-red-500">*</span>}</label>
                     <div className="relative">
                        <Input value={form.gtin || ''} onChange={e => setForm({...form, gtin: e.target.value})} disabled={form.hasVariants} placeholder={form.hasVariants ? "Preencha na guia Variações" : "Gerado automaticamente"} className={form.hasVariants ? "bg-slate-800 text-slate-500" : ""} />
                        {!form.hasVariants && <button type="button" onClick={() => setForm({...form, gtin: generateEan13()})} className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-bold text-red-600">AUTO</button>}
                     </div>
                   </div>
                   <div>
                     <label className="block text-sm font-bold mb-1">Unidade</label>
                     <select 
                        className="w-full h-10 px-3 rounded-md border border-slate-600 bg-slate-900 text-sm focus:outline-none"
                        value={form.unit || 'un'}
                        onChange={e => setForm({...form, unit: e.target.value as Product['unit']})}
                     >
                      <option value="un">Unidade (un)</option>
                      <option value="kit">Kit</option>
                      <option value="par">Par</option>
                      <option value="peça">Peça</option>
                      <option value="ml">Mililitro (ml)</option>
                      <option value="g">Grama (g)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-slate-800 rounded-xl border">
                   <div>
                     <label className="block text-sm font-bold mb-1 flex items-center justify-between">
                       {form.hasVariants ? "Estoque Total (Variações)" : "Estoque Atual"}
                       <span className="text-[10px] text-slate-400 font-normal ml-2">
                         {form.hasVariants ? "(Soma automática)" : "(Apenas conferência)"}
                       </span>
                     </label>
                     <Input 
                        type="number" 
                        value={form.stock ?? 0} 
                        disabled 
                        title={form.hasVariants ? "O estoque é a soma de todas as variações ativas." : "O estoque deve ser gerenciado através do módulo Movimentação de Estoque."} 
                        className="bg-slate-950 cursor-not-allowed text-slate-400 font-semibold"
                     />
                     <p className="text-[10px] text-red-500 mt-1 leading-tight">
                       {form.hasVariants 
                         ? "O estoque principal é sincronizado automaticamente com as variações." 
                         : 'Use o módulo "Mov. Estoque" para dar entrada/saída.'}
                     </p>
                   </div>
                   <div>
                     <label className="block text-sm font-bold mb-1">Estoque Mínimo (Alerta)</label>
                     <Input type="number" value={form.minStock ?? 0} onChange={e => setForm({...form, minStock: Number(e.target.value)})} />
                   </div>
                   <div className="flex items-center gap-2">
                      <input type="checkbox" id="backorder" checked={form.allowBackorder} onChange={e => setForm({...form, allowBackorder: e.target.checked})} className="w-4 h-4 text-red-600 rounded" />
                      <label htmlFor="backorder" className="text-sm font-bold">Permitir venda sem estoque</label>
                   </div>
                </div>
              </div>
            )}

            {/* 3. VARIAÇÕES */}
            {activeTab === 'variants' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <div className="flex justify-between items-end border-b pb-2">
                   <h3 className="text-lg font-bold">Gerenciador de Variações</h3>
                   <div className="flex items-center gap-2 text-xs bg-red-50 text-red-600 p-2 rounded-lg font-bold border border-red-100">
                     <Layers size={14} /> {variants.length} variações criadas
                   </div>
                </div>

                <div className="bg-slate-800 p-4 rounded-xl border space-y-4">
                  <p className="text-xs font-bold text-slate-400 uppercase">Gerador Automático</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                     <div>
                       <label className="text-xs font-bold block mb-1">Atributo (ex: Tamanho)</label>
                       <Input value={attrInput.name} onChange={e => setAttrInput({...attrInput, name: e.target.value})} placeholder="Tamanho" />
                     </div>
                     <div className="md:col-span-1 lg:col-span-2">
                       <label className="text-xs font-bold block mb-1">Valores (separados por vírgula)</label>
                       <div className="flex gap-2">
                         <Input value={attrInput.values} onChange={e => setAttrInput({...attrInput, values: e.target.value})} placeholder="P, M, G, GG" />
                         <Button type="button" onClick={addAttribute} variant="outline" className="shrink-0"><Plus size={18}/></Button>
                       </div>
                     </div>
                  </div>
                  
                  {tempAttrs.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-2">
                      {tempAttrs.map((at, idx) => (
                        <div key={idx} className="bg-slate-900 border text-sm px-3 py-1.5 rounded-full flex items-center gap-2 shadow-sm">
                          <span className="font-bold text-slate-400">{at.name}:</span>
                          <span>{at.values.join(', ')}</span>
                          <button onClick={() => setTempAttrs(tempAttrs.filter((_, i) => i !== idx))} className="text-red-500 hover:text-red-700 transition-colors"><X size={14}/></button>
                        </div>
                      ))}
                    </div>
                  )}

                  <Button type="button" onClick={generateVariants} disabled={tempAttrs.length === 0} className="w-full bg-slate-900">
                    Gerar Combinações
                  </Button>
                </div>

                <div className="space-y-4">
                  {variants.map((v, i) => (
                    <div key={i} className="group flex flex-col p-4 bg-slate-900 border border-slate-700 rounded-xl hover:border-red-200 transition-all shadow-sm gap-4">
                       <div className="flex flex-col md:flex-row gap-4">
                         <div className="w-20 h-20 bg-slate-950 rounded-xl flex items-center justify-center shrink-0 border overflow-hidden relative group/img">
                           {v.imageUrl ? <img src={v.imageUrl} className="w-full h-full object-cover" /> : <ImageIcon size={24} className="text-slate-300" />}
                           <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center text-[8px] text-white font-bold uppercase text-center p-1">Selecionar Imagem</div>
                         </div>
                         
                         <div className="flex-1 space-y-3">
                            <div className="flex justify-between items-start">
                              <span className="font-bold text-slate-100 text-sm">{v.name}</span>
                              <button onClick={() => setVariants(variants.filter((_, idx) => idx !== i))} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 size={16} /></button>
                            </div>
                            
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                              <div>
                                <label className="text-[10px] uppercase font-black text-slate-400 block mb-0.5">SKU</label>
                                <input className="w-full h-8 text-xs bg-slate-800 border rounded px-2 focus:ring-1 focus:ring-red-500 outline-none" value={v.sku || ''} onChange={e => {const nv = [...variants]; nv[i].sku = e.target.value; setVariants(nv)}} />
                              </div>
                              <div>
                                <label className="text-[10px] uppercase font-black text-slate-400 block mb-0.5">Barras (EAN)</label>
                                <div className="relative">
                                  <input className="w-full h-8 text-xs bg-slate-800 border rounded pl-2 pr-10 focus:ring-1 focus:ring-red-500 outline-none" value={v.barcode || ''} onChange={e => {const nv = [...variants]; nv[i].barcode = e.target.value; setVariants(nv)}} placeholder="789..." />
                                  <button type="button" onClick={() => {const nv = [...variants]; nv[i].barcode = generateEan13(); setVariants(nv)}} className="absolute right-1 top-1/2 -translate-y-1/2 text-[9px] font-bold text-red-600 bg-red-950 px-1 rounded">AUTO</button>
                                </div>
                              </div>
                              <div>
                                <label className="text-[10px] uppercase font-black text-slate-400 block mb-0.5">Preço (R$)</label>
                                <input type="number" step="0.01" className="w-full h-8 text-xs bg-slate-800 border rounded px-2 focus:ring-1 focus:ring-red-500 outline-none" value={v.price === null || v.price === undefined ? '' : v.price} onChange={e => {const nv = [...variants]; nv[i].price = e.target.value === '' ? 0 : Number(e.target.value); setVariants(nv)}} />
                              </div>
                              <div>
                                <label className="text-[10px] uppercase font-black text-slate-400 block mb-0.5">P. Custo (R$)</label>
                                <input type="number" step="0.01" className="w-full h-8 text-xs bg-slate-800 border rounded px-2 focus:ring-1 focus:ring-red-500 outline-none" value={v.costPrice === null || v.costPrice === undefined ? '' : v.costPrice} onChange={e => {const nv = [...variants]; nv[i].costPrice = e.target.value === '' ? 0 : Number(e.target.value); setVariants(nv)}} />
                              </div>
                              <div>
                                <label className="text-[10px] uppercase font-black text-slate-400 block mb-0.5" title="Apenas leitura. Use o mód. Movimentações.">Estoque (Leitura)</label>
                                <input 
                                  className="w-full h-8 text-xs bg-slate-950 text-slate-400 font-bold border border-slate-700 rounded px-2 cursor-not-allowed outline-none" 
                                  value={v.stock ?? 0} 
                                  disabled 
                                  title="O estoque deve ser gerenciado através do módulo Movimentação de Estoque."
                                />
                              </div>
                              <div className="flex items-end">
                                 <button 
                                   type="button" 
                                   onClick={() => {const nv = [...variants]; nv[i].active = !nv[i].active; setVariants(nv)}}
                                   className={cn("h-8 px-3 rounded text-[10px] font-black uppercase w-full transition-colors", v.active ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-slate-950 text-slate-400 hover:bg-slate-200")}
                                 >
                                   {v.active ? 'Ativo' : 'Inativo'}
                                 </button>
                              </div>
                            </div>
                         </div>
                       </div>

                       {/* Image Selector for Variant */}
                       {form.images.length > 0 && (
                         <div className="border-t pt-3">
                           <p className="text-[10px] font-black uppercase text-slate-400 mb-2">Vincular Imagem específica:</p>
                           <div className="flex flex-wrap gap-2">
                             {form.images.map((img, imgIdx) => (
                               <button 
                                 key={imgIdx}
                                 type="button"
                                 onClick={() => {
                                   const nv = [...variants];
                                   nv[i].imageUrl = img.url;
                                   setVariants(nv);
                                 }}
                                 className={cn(
                                   "w-10 h-10 rounded-lg border-2 transition-all shrink-0 overflow-hidden",
                                   v.imageUrl === img.url ? "border-red-600 scale-105 shadow-md" : "border-transparent opacity-40 hover:opacity-100"
                                 )}
                               >
                               <img src={img.url || undefined} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                               </button>
                             ))}
                             <button 
                               type="button"
                               onClick={() => {
                                 const nv = [...variants];
                                 delete nv[i].imageUrl;
                                 setVariants(nv);
                               }}
                               className={cn(
                                 "w-10 h-10 rounded-lg border-2 border-dashed flex items-center justify-center text-slate-400 hover:text-red-500 hover:border-red-500 transition-all text-[8px] font-bold uppercase",
                                 !v.imageUrl ? "border-red-600 bg-red-50 text-red-600" : "border-slate-700"
                               )}
                             >
                               Limpar
                             </button>
                           </div>
                         </div>
                       )}
                    </div>
                  ))}
                  {variants.length === 0 && (
                    <div className="text-center py-10 border-2 border-dashed rounded-2xl text-slate-400">
                      Nenhuma variação para este produto ainda.
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 4. MODA */}
            {activeTab === 'fashion' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <h3 className="text-lg font-bold border-b pb-2">Informações de Moda & Lingerie</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold mb-1">Gênero</label>
                    <select className="w-full h-10 px-3 border rounded-md" value={form.fashion?.gender || ''} onChange={e => setForm({...form, fashion: {...form.fashion, gender: e.target.value as Product['fashion'] extends {gender?: infer G} ? G : never}})}>
                      <option value="Feminino">Feminino</option>
                      <option value="Masculino">Masculino</option>
                      <option value="Unissex">Unissex</option>
                      <option value="Infantil">Infantil</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-1">Material / Tecido</label>
                    <Input value={form.fashion?.material || ''} onChange={e => setForm({...form, fashion: {...form.fashion, material: e.target.value}})} placeholder="Ex: Seda, Algodão, Renda" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-bold mb-1">Composição</label>
                    <Input value={form.fashion?.composition || ''} onChange={e => setForm({...form, fashion: {...form.fashion, composition: e.target.value}})} placeholder="Ex: 90% Poliamida, 10% Elastano" />
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-800 p-4 rounded-xl">
                   <div className="flex items-center gap-2">
                      <input type="checkbox" id="bojo" checked={form.fashion?.hasPadding} onChange={e => setForm({...form, fashion: {...form.fashion, hasPadding: e.target.checked}})} className="w-4 h-4" />
                      <label htmlFor="bojo" className="text-sm font-bold">Possui Bojo</label>
                   </div>
                   <div className="flex items-center gap-2">
                      <input type="checkbox" id="aro" checked={form.fashion?.hasUnderwire} onChange={e => setForm({...form, fashion: {...form.fashion, hasUnderwire: e.target.checked}})} className="w-4 h-4" />
                      <label htmlFor="aro" className="text-sm font-bold">Possui Aro</label>
                   </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div>
                     <label className="block text-sm font-bold mb-1">Instruções de Lavagem</label>
                     <textarea className="w-full h-24 border p-3 rounded" value={form.fashion?.washingInstructions || ''} onChange={e => setForm({...form, fashion: {...form.fashion, washingInstructions: e.target.value}})} />
                   </div>
                   <div>
                     <label className="block text-sm font-bold mb-1">Tabela de Medidas (Texto ou HTML)</label>
                     <textarea className="w-full h-24 border p-3 rounded" value={form.fashion?.sizeTable || ''} onChange={e => setForm({...form, fashion: {...form.fashion, sizeTable: e.target.value}})} />
                   </div>
                </div>
              </div>
            )}

            {/* 5. COSMETICOS */}
            {activeTab === 'cosmetics' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <h3 className="text-lg font-bold border-b pb-2">Informações de Cosméticos</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold mb-1">Área de Uso</label>
                    <Input value={form.cosmetics?.usageArea || ''} onChange={e => setForm({...form, cosmetics: {...form.cosmetics, usageArea: e.target.value}})} placeholder="Rosto, Corpo, Íntimo..." />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-1">Volume (ml/g)</label>
                    <Input value={form.cosmetics?.volume || ''} onChange={e => setForm({...form, cosmetics: {...form.cosmetics, volume: e.target.value}})} placeholder="60ml, 150g..." />
                  </div>
                </div>

                <div>
                   <label className="block text-sm font-bold mb-1">Modo de Uso</label>
                   <textarea className="w-full h-24 border p-3 rounded" value={form.cosmetics?.usageMode || ''} onChange={e => setForm({...form, cosmetics: {...form.cosmetics, usageMode: e.target.value}})} />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-800 p-4 rounded-xl border border-slate-700">
                    <div className="flex flex-col items-center justify-center p-2 rounded-lg bg-slate-900 border">
                        <input type="checkbox" id="vegan" checked={form.cosmetics?.vegan} onChange={e => setForm({...form, cosmetics: {...form.cosmetics, vegan: e.target.checked}})} className="w-5 h-5 text-green-600 mb-1" />
                        <label htmlFor="vegan" className="text-[10px] font-bold uppercase text-slate-400">Vegano</label>
                    </div>
                    <div className="flex flex-col items-center justify-center p-2 rounded-lg bg-slate-900 border">
                        <input type="checkbox" id="cruelty" checked={form.cosmetics?.crueltyFree} onChange={e => setForm({...form, cosmetics: {...form.cosmetics, crueltyFree: e.target.checked}})} className="w-5 h-5 text-green-600 mb-1" />
                        <label htmlFor="cruelty" className="text-[10px] font-bold uppercase text-slate-400">Cruelty Free</label>
                    </div>
                    <div className="flex flex-col items-center justify-center p-2 rounded-lg bg-slate-900 border">
                        <input type="checkbox" id="dermato" checked={form.cosmetics?.dermatologicallyTested} onChange={e => setForm({...form, cosmetics: {...form.cosmetics, dermatologicallyTested: e.target.checked}})} className="w-5 h-5 text-blue-600 mb-1" />
                        <label htmlFor="dermato" className="text-[10px] font-bold uppercase text-slate-400">Dermato Testado</label>
                    </div>
                    <div className="flex flex-col items-center justify-center p-2 rounded-lg bg-slate-900 border">
                        <input type="checkbox" id="hipo" checked={form.cosmetics?.hypoallergenic} onChange={e => setForm({...form, cosmetics: {...form.cosmetics, hypoallergenic: e.target.checked}})} className="w-5 h-5 text-blue-600 mb-1" />
                        <label htmlFor="hipo" className="text-[10px] font-bold uppercase text-slate-400">Hipoalergênico</label>
                    </div>
                </div>
              </div>
            )}

            {/* 6. IMAGENS */}
            {activeTab === 'images' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <div className="flex justify-between items-center border-b pb-2">
                   <h3 className="text-lg font-bold">Galeria de Imagens</h3>
                   <div className="text-xs text-slate-400 font-bold uppercase">Mínimo 1 imagem recomendada</div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                   {form.images.map((img, i) => (
                     <div key={i} className={cn("group relative aspect-square rounded-xl overflow-hidden border-2 transition-all", img.isMain ? "border-red-500 shadow-md" : "border-slate-700 hover:border-slate-600")}>
                        <img 
                          src={img.url || undefined} 
                          className="w-full h-full object-cover" 
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = PLACEHOLDER_IMAGE;
                          }}
                        />
                        {img.isMain && <div className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow">CAPA</div>}
                        <div className="absolute inset-x-0 bottom-0 bg-black/60 translate-y-full group-hover:translate-y-0 transition-transform flex p-2 gap-1 justify-center">
                           {!img.isMain && <button type="button" onClick={() => setMainImage(i)} className="p-1.5 bg-slate-900 text-white rounded-md hover:bg-red-50" title="Definir como principal"><Check size={14}/></button>}
                           <button type="button" onClick={() => removeImage(i)} className="p-1.5 bg-slate-900 text-red-600 rounded-md hover:bg-red-50" title="Remover"><Trash2 size={14}/></button>
                        </div>
                     </div>
                   ))}

                   {/* Add Image Button */}
                   <label className="aspect-square border-2 border-dashed border-slate-600 rounded-xl flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-slate-800 hover:border-red-400 transition-all text-slate-400 hover:text-red-500">
                      <input type="file" multiple accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploading} />
                      {uploading ? <div className="w-6 h-6 border-2 border-red-500 border-t-transparent rounded-full animate-spin"></div> : <><Upload size={24} /> <span className="text-[10px] font-bold uppercase tracking-widest">Adicionar</span></>}
                   </label>
                </div>
              </div>
            )}

            {/* 8. SEO */}
            {activeTab === 'seo' && (
              <div className="space-y-6 motion-safe:animate-in fade-in slide-in-from-right-2">
                <h3 className="text-lg font-bold border-b pb-2">Otimização (SEO)</h3>
                <div className="space-y-4">
                   <div>
                     <label className="block text-sm font-bold mb-1">Slug da URL (Link)</label>
                     <div className="flex gap-2">
                       <span className="h-10 bg-slate-800 border rounded-md px-3 flex items-center text-xs text-slate-400">loja.com/produto/</span>
                       <Input value={form.seo?.slug || ''} onChange={e => setForm({...form, seo: {...form.seo!, slug: e.target.value}})} />
                     </div>
                   </div>
                   <div>
                     <label className="block text-sm font-bold mb-1">Título da Página (Meta Title)</label>
                     <Input value={form.seo?.metaTitle || ''} onChange={e => setForm({...form, seo: {...form.seo!, metaTitle: e.target.value}})} placeholder="Padrão: Nome do Produto" />
                   </div>
                   <div>
                     <label className="block text-sm font-bold mb-1">Meta Descrição</label>
                     <textarea className="w-full h-24 border p-3 rounded text-sm" value={form.seo?.metaDescription || ''} onChange={e => setForm({...form, seo: {...form.seo!, metaDescription: e.target.value}})} />
                   </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
                      <div>
                        <label className="block text-sm font-bold mb-1">Palavras-chave (IA)</label>
                        <div className="flex flex-wrap gap-1 p-2 bg-slate-950 border border-slate-700 rounded-md min-h-[40px]">
                           {form.ai_keywords?.map((k, i) => (
                             <span key={i} className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full text-slate-300 flex items-center gap-1">
                               {k}
                               <button type="button" onClick={() => setForm({...form, ai_keywords: form.ai_keywords?.filter((_, idx) => idx !== i)})} className="hover:text-red-500"><X size={10}/></button>
                             </span>
                           ))}
                           <input 
                             placeholder="Digite e Enter..."
                             className="bg-transparent border-none outline-none text-xs flex-1 min-w-[100px]"
                             onKeyDown={e => {
                               if (e.key === 'Enter') {
                                 e.preventDefault();
                                 const val = e.currentTarget.value.trim();
                                 if (val) {
                                   setForm({...form, ai_keywords: [...(form.ai_keywords || []), val]});
                                   e.currentTarget.value = '';
                                 }
                               }
                             }}
                           />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-bold mb-1">Sinônimos (IA)</label>
                        <div className="flex flex-wrap gap-1 p-2 bg-slate-950 border border-slate-700 rounded-md min-h-[40px]">
                           {form.ai_synonyms?.map((s, i) => (
                             <span key={i} className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full text-slate-300 flex items-center gap-1">
                               {s}
                               <button type="button" onClick={() => setForm({...form, ai_synonyms: form.ai_synonyms?.filter((_, idx) => idx !== i)})} className="hover:text-red-500"><X size={10}/></button>
                             </span>
                           ))}
                           <input 
                             placeholder="Digite e Enter..."
                             className="bg-transparent border-none outline-none text-xs flex-1 min-w-[100px]"
                             onKeyDown={e => {
                               if (e.key === 'Enter') {
                                 e.preventDefault();
                                 const val = e.currentTarget.value.trim();
                                 if (val) {
                                   setForm({...form, ai_synonyms: [...(form.ai_synonyms || []), val]});
                                   e.currentTarget.value = '';
                                 }
                               }
                             }}
                           />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 p-4 bg-red-600/5 rounded-xl border border-red-600/10">
                       <div className={cn(
                         "w-3 h-3 rounded-full",
                         form.embedding && form.embedding.length > 0 ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" : "bg-slate-500"
                       )} />
                       <div className="flex-1">
                         <p className="text-xs font-bold text-slate-200">Vetores de Busca Semântica (Embeddings)</p>
                         <p className="text-[10px] text-slate-400">
                           {form.embedding && form.embedding.length > 0 
                             ? `Vetor de ${form.embedding.length} dimensões carregado. Otimizado para busca inteligente.`
                             : "Embeddings ausentes. Use o botão 'Gerar com IA' no topo para otimizar este produto para busca semântica."}
                         </p>
                       </div>
                    </div>
                </div>
              </div>
            )}

            {/* Default Case for other tabs */}
            {!['general', 'price', 'variants', 'fashion', 'cosmetics', 'images', 'seo'].includes(activeTab) && (
              <div className="h-full flex items-center justify-center opacity-40">
                <p>Seção {activeTab} em desenvolvimento...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

    const filteredProducts = products.filter(p => {
        // Text Search
        const term = searchTerm.toLowerCase();
        const termMatch = !searchTerm || (
            p.name?.toLowerCase().includes(term) || 
            p.sku?.toLowerCase().includes(term) || 
            p.gtin?.toLowerCase().includes(term) || 
            p.searchTerms?.some(st => st.includes(term))
        );

        if (!termMatch) return false;

        // Image Filter
        if (filters.hasImage === 'yes' && (!p.images || p.images.length === 0)) return false;
        if (filters.hasImage === 'no' && p.images && p.images.length > 0) return false;

        // Stock Filter
        const stock = p.stock || 0;
        const minStock = p.minStock || 0;
        if (filters.stockStatus === 'in_stock' && stock <= 0) return false;
        if (filters.stockStatus === 'out_of_stock' && stock > 0) return false;
        if (filters.stockStatus === 'low_stock' && (stock <= 0 || stock > minStock)) return false;

        // Category Filter
        if (filters.categoryId !== 'all') {
          const inCategories = p.categoryIds?.includes(filters.categoryId);
          const isLegacyCat = p.categoryId === filters.categoryId;
          if (!inCategories && !isLegacyCat) return false;
        }

        // Status Filter
        if (filters.status === 'active' && !p.active) return false;
        if (filters.status === 'inactive' && p.active) return false;

        // Catalog Filter
        if (filters.showInCatalog === 'yes' && p.extras?.showInCatalog === false) return false;
        if (filters.showInCatalog === 'no' && p.extras?.showInCatalog !== false) return false;

        // Highlights Filter
        if (filters.featured === 'yes' && !p.featured) return false;
        if (filters.featured === 'no' && p.featured) return false;

        // New Release Filter
        if (filters.newRelease === 'yes' && !p.newRelease) return false;
        if (filters.newRelease === 'no' && p.newRelease) return false;

        // Variants Filter
        if (filters.hasVariants === 'yes' && !p.hasVariants) return false;
        if (filters.hasVariants === 'no' && p.hasVariants) return false;

        return true;
    });

  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / itemsPerPage));
  const currentProducts = filteredProducts.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  // LIST VIEW
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Catálogo de Produtos</h1>
          <p className="text-slate-400">Gerencie seu inventário, variações e mídia em um só lugar.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            onClick={handleBulkSEO}
            className="bg-red-600 hover:bg-red-700 shadow-xl shadow-red-950/20"
          >
            <Sparkles size={18} className="mr-2" /> SEO em Massa
          </Button>
          {canCreate && (
            <Button onClick={handleNew} className="bg-slate-950 hover:bg-slate-800 shadow-xl shadow-slate-200">
               <Plus size={18} className="mr-2" /> Novo Produto
            </Button>
          )}
        </div>
      </div>

      <div className="bg-slate-900 rounded-2xl shadow-sm border border-slate-700 overflow-hidden">
        <div className="p-4 border-b bg-slate-800/50 space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative w-full md:w-96 flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <Input 
                  placeholder="Buscar por nome, SKU ou Código..." 
                  className="pl-10 h-10" 
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                  }}
                />
              </div>
              <Button 
                variant="outline" 
                className={cn("h-10 px-3", showFilters && "bg-slate-700")}
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter size={18} className={cn("mr-2", showFilters && "text-red-500")} />
                Filtros
                {showFilters ? <ChevronUp size={14} className="ml-1" /> : <ChevronDown size={14} className="ml-1" />}
              </Button>
            </div>
            <div className="flex items-center gap-4 text-xs font-bold text-slate-400">
               {selectedIds.length > 0 && (
                 <div className="flex items-center gap-2 pr-4 border-r border-slate-700">
                   <span className="text-red-500 font-black">{selectedIds.length} Selecionados:</span>
                   <div className="relative group">
                     <button className="flex items-center gap-1 text-[10px] uppercase font-black bg-slate-800 hover:bg-slate-700 p-1.5 rounded transition-colors text-slate-300">
                       Destaque <ChevronDown size={12} />
                     </button>
                     <div className="absolute top-full right-0 mt-1 w-44 bg-slate-900 border border-slate-700 rounded-lg shadow-xl z-20 hidden group-hover:block">
                       <button onClick={() => handleBulkAction('addToFeatured')} className="block w-full text-left px-4 py-3 text-xs font-bold hover:bg-slate-800">Definir como Destaque</button>
                       <button onClick={() => handleBulkAction('removeFromFeatured')} className="block w-full text-left px-4 py-3 text-xs font-bold hover:bg-slate-800 text-red-500">Remover dos Destaques</button>
                     </div>
                   </div>
                   <div className="relative group">
                     <button className="flex items-center gap-1 text-[10px] uppercase font-black bg-slate-800 hover:bg-slate-700 p-1.5 rounded transition-colors text-slate-300">
                       Lançamento <ChevronDown size={12} />
                     </button>
                     <div className="absolute top-full right-0 mt-1 w-46 bg-slate-900 border border-slate-700 rounded-lg shadow-xl z-20 hidden group-hover:block">
                       <button onClick={() => handleBulkAction('addToNewRelease')} className="block w-full text-left px-4 py-3 text-xs font-bold hover:bg-slate-800">Definir como Lançamento</button>
                       <button onClick={() => handleBulkAction('removeFromNewRelease')} className="block w-full text-left px-4 py-3 text-xs font-bold hover:bg-slate-800 text-red-500">Remover dos Lançamentos</button>
                     </div>
                   </div>
                   <div className="relative group">
                     <button className="flex items-center gap-1 text-[10px] uppercase font-black bg-slate-800 hover:bg-slate-700 p-1.5 rounded transition-colors text-slate-300">
                       Categorias <ChevronDown size={12} />
                     </button>
                     <div className="absolute top-full right-0 mt-1 w-40 bg-slate-900 border border-slate-700 rounded-lg shadow-xl z-20 hidden group-hover:block">
                       <button onClick={() => { setBulkCategoryAction('add'); setIsBulkCategoryModalOpen(true); }} className="block w-full text-left px-4 py-3 text-xs font-bold hover:bg-slate-800">Adicionar</button>
                       <button onClick={() => { setBulkCategoryAction('remove'); setIsBulkCategoryModalOpen(true); }} className="block w-full text-left px-4 py-3 text-xs font-bold hover:bg-slate-800 text-red-500">Remover</button>
                     </div>
                   </div>
                   <button 
                     onClick={handleBulkSEO} 
                     disabled={isBulkRunning}
                     className={cn(
                       "p-1.5 rounded transition-colors flex items-center gap-1",
                       isBulkRunning ? "text-slate-500 bg-slate-800" : "hover:bg-slate-700 text-purple-400 font-black uppercase text-[10px]"
                     )} 
                     title="Gerar Conteúdo SEO com IA em Massa"
                   >
                     <Sparkles size={14} className={isBulkRunning ? "animate-pulse" : ""} />
                     {isBulkRunning ? 'Processando IA...' : 'SEO IA'}
                   </button>
                   <button onClick={() => handleBulkAction('activate')} className="p-1.5 hover:bg-slate-700 rounded text-slate-300 transition-colors" title="Tornar Ativos"><Package size={14} /></button>
                   <button onClick={() => handleBulkAction('deactivate')} className="p-1.5 hover:bg-slate-700 rounded text-slate-300 transition-colors" title="Tornar Indisponíveis"><PackageX size={14} /></button>
                   <button onClick={() => handleBulkAction('showInCatalog')} className="p-1.5 hover:bg-slate-700 rounded text-slate-300 transition-colors" title="Exibir no Site"><Eye size={14} /></button>
                   <button onClick={() => handleBulkAction('hideFromCatalog')} className="p-1.5 hover:bg-slate-700 rounded text-slate-300 transition-colors" title="Ocultar do Site"><EyeOff size={14} /></button>
                   <button onClick={() => handleBulkAction('delete')} className="p-1.5 hover:bg-slate-700 rounded text-red-500 transition-colors" title="Excluir Selecionados"><Trash2 size={14} /></button>
                   <button onClick={() => setSelectedIds([])} className="p-1.5 hover:bg-slate-700 rounded text-slate-500 transition-colors" title="Limpar Seleção"><X size={14} /></button>
                 </div>
               )}
               <span className="flex items-center gap-1"><Check size={14} className="text-green-500" /> {filteredProducts.filter(p => p.active).length} Ativos</span>
               <span className="flex items-center gap-1"><X size={14} className="text-red-500" /> {filteredProducts.filter(p => !p.active).length} Inativos</span>
            </div>
          </div>

          {showFilters && (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 p-4 bg-slate-900/50 rounded-xl border border-slate-700 motion-safe:animate-in fade-in slide-in-from-top-2">
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Imagem</label>
                <select 
                  className="w-full h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                  value={filters.hasImage}
                  onChange={e => setFilters({...filters, hasImage: e.target.value})}
                >
                  <option value="all">Todas</option>
                  <option value="yes">Com Imagem</option>
                  <option value="no">Sem Imagem</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Estoque</label>
                <select 
                  className="w-full h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                  value={filters.stockStatus}
                  onChange={e => setFilters({...filters, stockStatus: e.target.value})}
                >
                  <option value="all">Todos</option>
                  <option value="in_stock">Disponível</option>
                  <option value="out_of_stock">Esgotado</option>
                  <option value="low_stock">Estoque Baixo</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Categoria</label>
                <select 
                  className="w-full h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                  value={filters.categoryId}
                  onChange={e => setFilters({...filters, categoryId: e.target.value})}
                >
                  <option value="all">Todas</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Status</label>
                <select 
                  className="w-full h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                  value={filters.status}
                  onChange={e => setFilters({...filters, status: e.target.value})}
                >
                  <option value="all">Todos</option>
                  <option value="active">Ativo</option>
                  <option value="inactive">Inativo</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Catálogo</label>
                <select 
                  className="w-full h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                  value={filters.showInCatalog}
                  onChange={e => setFilters({...filters, showInCatalog: e.target.value})}
                >
                  <option value="all">Todos</option>
                  <option value="yes">Exibir</option>
                  <option value="no">Ocultar</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Destaque</label>
                <select 
                  className="w-full h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                  value={filters.featured}
                  onChange={e => setFilters({...filters, featured: e.target.value})}
                >
                  <option value="all">Todos</option>
                  <option value="yes">Sim</option>
                  <option value="no">Não</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Lançamento</label>
                <select 
                  className="w-full h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                  value={filters.newRelease}
                  onChange={e => setFilters({...filters, newRelease: e.target.value})}
                >
                  <option value="all">Todos</option>
                  <option value="yes">Sim</option>
                  <option value="no">Não</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-500">Variações</label>
                <div className="flex gap-2">
                  <select 
                    className="flex-1 h-8 bg-slate-800 border-slate-700 rounded text-[10px] px-2 outline-none focus:ring-1 focus:ring-red-500"
                    value={filters.hasVariants}
                    onChange={e => setFilters({...filters, hasVariants: e.target.value})}
                  >
                    <option value="all">Todos</option>
                    <option value="yes">Com Variação</option>
                    <option value="no">Sem Variação</option>
                  </select>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 w-8 p-0 hover:bg-red-500/10 text-slate-500 hover:text-red-500"
                    onClick={clearFilters}
                    title="Limpar Filtros"
                  >
                    <X size={14} />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm min-w-[800px]">
             <thead className="bg-slate-800/80 text-slate-400 font-bold border-b text-[11px] uppercase tracking-widest">
                <tr>
                   <th className="px-6 py-4 w-12 text-center">
                     <button onClick={toggleSelectAll} className="hover:text-red-500 transition-colors">
                        {selectedIds.length === currentProducts.length && currentProducts.length > 0 ? <CheckSquare size={16} /> : <Square size={16} />}
                     </button>
                   </th>
                   <th className="px-6 py-4">Produto</th>
                   <th className="px-6 py-4">Estoque</th>
                   <th className="px-6 py-4">Preço</th>
                   <th className="px-6 py-4">Variações</th>
                   <th className="px-6 py-4 text-center">Ações</th>
                </tr>
             </thead>
             <tbody className="divide-y">
                {loading ? (
                  <tr><td colSpan={6} className="p-12 text-center text-slate-300">Carregando inventário...</td></tr>
                ) : currentProducts.length === 0 ? (
                  <tr><td colSpan={6} className="p-12 text-center text-slate-300">Nenhum produto encontrado.</td></tr>
                ) : currentProducts.map((prod, index) => (
                  <tr key={prod.id} className={cn("hover:bg-slate-950 group transition-colors", selectedIds.includes(prod.id!) && "bg-slate-900/50")}>
                     <td className="px-6 py-4 text-center">
                        <button onClick={() => toggleSelect(prod.id!)} className="text-slate-500 hover:text-red-500 transition-all mb-1">
                          {selectedIds.includes(prod.id!) ? <CheckSquare size={16} className="text-red-600" /> : <Square size={16} />}
                        </button>
                        <div className="text-[10px] text-slate-700 font-bold"># {((currentPage - 1) * itemsPerPage) + index + 1}</div>
                     </td>
                     <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                           <div className="w-14 h-14 bg-slate-950 rounded-xl overflow-hidden shadow-sm shrink-0 border border-slate-700">
                              {prod.images?.[0]?.url ? (
                                <img 
                                  src={prod.images[0].url || undefined} 
                                  className="w-full h-full object-cover" 
                                  referrerPolicy="no-referrer"
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).src = PLACEHOLDER_IMAGE;
                                  }}
                                />
                              ) : (
                                <ImageIcon className="m-auto text-slate-300 mt-4" size={20} />
                              )}
                           </div>
                           <div className="flex flex-col min-w-0 max-w-[300px]">
                              <h4 className="font-bold text-white group-hover:text-red-600 transition-colors uppercase text-[12px] whitespace-normal break-words">{prod.name}</h4>
                              <span className="text-[10px] text-slate-400 font-black tracking-widest">{prod.sku || 'SEM SKU'}</span>
                              <div className="flex flex-wrap gap-1 mt-2">
                                 {prod.categoryIds && prod.categoryIds.length > 0 ? (
                                   prod.categoryIds.slice(0, 2).map(cid => (
                                     <span key={cid} className="bg-slate-900 border border-slate-700 text-slate-400 text-[8px] font-bold px-1 py-0.5 rounded leading-none uppercase">
                                       {categories.find(c => c.id === cid)?.name || 'Cat'}
                                     </span>
                                   ))
                                 ) : (
                                   <span className="bg-slate-900 border border-slate-700 text-slate-500 text-[8px] font-bold px-1 py-0.5 rounded leading-none uppercase italic">Sem Categoria</span>
                                 )}
                                 {prod.categoryIds && prod.categoryIds.length > 2 && (
                                   <span className="bg-slate-900 border border-slate-700 text-slate-500 text-[8px] font-bold px-1 py-0.5 rounded leading-none">+{prod.categoryIds.length - 2}</span>
                                 )}
                              </div>
                           </div>
                        </div>
                     </td>
                     <td className="px-6 py-4 font-black text-slate-300">
                        {prod.stock || 0} <span className="text-[10px] font-normal uppercase opacity-40 ml-1">{prod.unit}</span>
                     </td>
                     <td className="px-6 py-4">
                        {prod.promoPrice && prod.promoPrice > 0 ? (
                           <>
                             <div className="font-bold text-emerald-400">{formatCurrency(prod.promoPrice)}</div>
                             <div className="text-[10px] text-slate-500 font-black line-through opacity-60">{formatCurrency(prod.price)}</div>
                           </>
                        ) : (
                           <div className="font-bold text-white">{formatCurrency(prod.price)}</div>
                        )}
                     </td>
                     <td className="px-6 py-4">
                       {prod.hasVariants ? (
                         <div className="flex items-center gap-1.5 text-red-600 font-black text-[10px] uppercase">
                           <Layers size={14} /> Multi-Opções
                         </div>
                       ) : <span className="text-slate-300 text-[10px] uppercase font-bold italic">Item Único</span>}
                     </td>
                     <td className="px-6 py-4">
                        <div className="flex justify-center gap-2">
                           {canEdit && (
                             <button 
                               onClick={() => {
                                 setTargetProduct(prod);
                                 setTargetCategoryIds(prod.categoryIds || (prod.categoryId ? [prod.categoryId] : []));
                                 setIsSingleCategoryModalOpen(true);
                               }} 
                               className="p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-300 hover:text-red-600 hover:border-red-600 transition-all shadow-sm group/btn"
                               title="Gerenciar Categorias"
                             >
                                <Plus size={16} className="group-hover/btn:scale-110 transition-transform" />
                             </button>
                           )}
                           {canEdit && (
                             <button onClick={() => handleEdit(prod)} className="p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-300 hover:text-red-600 hover:border-red-600 transition-all shadow-sm">
                               <Edit2 size={16} />
                             </button>
                           )}
                           {canDelete && (
                             <button onClick={() => handleDelete(prod.id!, prod.name)} className="p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-300 hover:text-red-600 hover:border-red-600 transition-all">
                               <Trash2 size={16} />
                             </button>
                           )}
                           {!canEdit && !canDelete && <span className="text-[10px] text-zinc-400 font-black italic tracking-widest uppercase opacity-50">Bloqueado</span>}
                        </div>
                     </td>
                  </tr>
                ))}
             </tbody>
          </table>
        </div>
        
        {totalPages > 1 && (
          <div className="p-4 border-t bg-slate-800/50 flex flex-col sm:flex-row items-center justify-between gap-4">
             <div className="text-xs text-slate-400 font-bold">
               Mostrando {((currentPage - 1) * itemsPerPage) + 1} a {Math.min(currentPage * itemsPerPage, filteredProducts.length)} de {filteredProducts.length} produtos
             </div>
             <div className="flex items-center gap-1">
               <Button 
                 variant="outline" 
                 size="sm" 
                 onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                 disabled={currentPage === 1}
                 className="bg-slate-900"
               >
                 Anterior
               </Button>
               
               <div className="flex items-center mx-2 gap-1">
                 {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => {
                   // Show few pages around current page to avoid huge pagination
                   if (totalPages > 7) {
                     if (page !== 1 && page !== totalPages && Math.abs(currentPage - page) > 2) {
                       if (page === 2 || page === totalPages - 1) return <span key={page} className="text-slate-500">...</span>;
                       return null;
                     }
                   }
                   return (
                     <button
                       key={page}
                       onClick={() => setCurrentPage(page)}
                       className={cn(
                         "w-8 h-8 rounded-md flex items-center justify-center text-xs font-bold transition-colors",
                         currentPage === page 
                           ? "bg-red-600 text-white" 
                           : "bg-slate-900 text-slate-300 hover:bg-slate-800"
                       )}
                     >
                       {page}
                     </button>
                   );
                 })}
               </div>

               <Button 
                 variant="outline" 
                 size="sm" 
                 onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                 disabled={currentPage === totalPages}
                 className="bg-slate-900"
               >
                 Próximo
               </Button>
             </div>
          </div>
        )}
      </div>
      {/* MODAL SINGLE CATEGORY */}
      {isSingleCategoryModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl flex flex-col">
            <header className="p-6 border-b border-slate-800 bg-slate-800/50 flex items-center justify-between">
               <div>
                  <h2 className="text-lg font-bold text-white uppercase text-[14px]">Gerenciar Categorias</h2>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">{targetProduct?.name}</p>
               </div>
               <button onClick={() => setIsSingleCategoryModalOpen(false)} className="text-slate-500 hover:text-white"><X size={20}/></button>
            </header>
            <div className="p-6 flex flex-col gap-4">
              <label className="text-xs font-bold text-slate-400">Marque as categorias deste produto</label>
              <div className="max-h-80 overflow-y-auto bg-slate-800 border border-slate-700 rounded-lg p-2 space-y-2 custom-scrollbar">
                {groupedCategories.map((root: any) => (
                  <div key={root.id}>
                    <p className="text-[10px] font-black uppercase text-slate-500 bg-slate-950 p-2 mb-1 sticky top-0 rounded">{root.name}</p>
                    {[root, ...root.allChildren].sort((a,b) => a.name.localeCompare(b.name)).map((c: any) => (
                       <label key={c.id} className="flex items-center gap-2 p-2 hover:bg-slate-700 rounded cursor-pointer transition-colors group">
                          <input 
                            type="checkbox" 
                            checked={targetCategoryIds.includes(c.id)}
                            onChange={(e) => {
                               if (e.target.checked) setTargetCategoryIds([...targetCategoryIds, c.id]);
                               else setTargetCategoryIds(targetCategoryIds.filter(id => id !== c.id));
                            }}
                            className="w-4 h-4 accent-red-600"
                          />
                          <span className={cn("text-xs transition-colors", targetCategoryIds.includes(c.id) ? "text-red-500 font-bold" : "text-slate-400")}>{c.name}</span>
                       </label>
                    ))}
                  </div>
                ))}
              </div>
            </div>
            <footer className="p-6 border-t border-slate-800 flex gap-3 bg-slate-800/20">
              <Button variant="outline" className="flex-1" onClick={() => setIsSingleCategoryModalOpen(false)}>Cancelar</Button>
              <Button className="flex-1 bg-red-600 hover:bg-red-700" onClick={handleSingleCategoryUpdate} disabled={loading}>
                {loading ? 'Salvando...' : 'Salvar'}
              </Button>
            </footer>
          </div>
        </div>
      )}

      {/* MODAL IA BULK SEO */}
      {isBulkModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <header className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-800/50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-600 rounded-lg shadow-lg shadow-red-900/20">
                  <Sparkles size={20} className="text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">SEO Inteligente de Produtos</h2>
                  <p className="text-xs text-slate-400">Otimização automática via OpenAI GPT-4o</p>
                </div>
              </div>
              <button 
                onClick={() => !isBulkRunning && setIsBulkModalOpen(false)}
                disabled={isBulkRunning}
                className="p-2 hover:bg-slate-700 rounded-full text-slate-400 transition-colors disabled:opacity-50"
              >
                <X size={20} />
              </button>
            </header>

            <div className="p-6 overflow-y-auto flex-1 space-y-6">
              {!isBulkRunning && bulkProgress.processed === 0 ? (
                <>
                  <div className="space-y-4">
                    <p className="text-sm text-slate-300 font-medium">Configurações de Geração:</p>
                    
                    <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-2xl border border-slate-700">
                      <div className="flex items-center gap-3">
                        <AlertCircle size={20} className="text-yellow-500" />
                        <div>
                          <p className="font-bold text-sm text-slate-200">Forçar regeneração completa</p>
                          <p className="text-xs text-slate-400">Sobrescrever conteúdos e SEO já existentes.</p>
                        </div>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={forceRegen} 
                        onChange={e => setForceRegen(e.target.checked)}
                        className="w-5 h-5 accent-red-600"
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-blue-900/10 border border-blue-900/30 rounded-2xl">
                    <p className="text-xs text-blue-400 leading-relaxed text-center">
                      Este processo utilizará a inteligência artificial para analisar o nome e categorias de cada produto para gerar um copy luxuoso e metadados otimizados.
                    </p>
                  </div>
                </>
              ) : (
                <div className="space-y-6 py-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">Progresso de Otimização</span>
                      <span className="font-bold text-white">{Math.round((bulkProgress.processed / bulkProgress.total) * 100)}%</span>
                    </div>
                    <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                      <div 
                        className="h-full bg-red-600 transition-all duration-500 rounded-full"
                        style={{ width: `${(bulkProgress.processed / bulkProgress.total) * 100}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-[10px] uppercase tracking-wider font-bold">
                       <span className="text-slate-400">{bulkProgress.processed} de {bulkProgress.total} produtos</span>
                       <div className="flex gap-4">
                         <span className="text-green-500">{bulkProgress.updated} atualizados</span>
                         <span className="text-yellow-500">{bulkProgress.skipped} pulados</span>
                       </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Atividade da IA</p>
                    <div className="bg-black/40 rounded-2xl p-4 h-48 overflow-y-auto font-mono text-[11px] border border-slate-800 custom-scrollbar">
                      {bulkProgress.logs.map((log, idx) => (
                        <div key={idx} className={cn(
                          "py-1 border-b border-white/5 last:border-0",
                          log.includes('[ERRO]') ? "text-red-400" : 
                          log.includes('[SUCESSO]') ? "text-green-400" : 
                          log.includes('[PULADO]') ? "text-yellow-400" : "text-slate-300"
                        )}>
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>

                  {isBulkRunning && (
                    <div className="flex flex-col items-center gap-3">
                      <Loader2 className="text-red-600 animate-spin" size={32} />
                      <p className="text-xs text-slate-400 animate-pulse">A IA está escrevendo o conteúdo agora...</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            <footer className="p-6 border-t border-slate-800 bg-slate-800/20 flex items-center justify-end gap-3">
              <Button 
                variant="outline" 
                onClick={() => setIsBulkModalOpen(false)}
                disabled={isBulkRunning}
              >
                {isBulkRunning ? 'Processando...' : (bulkProgress.processed > 0 ? 'Fechar' : 'Cancelar')}
              </Button>
              {!isBulkRunning && bulkProgress.processed === 0 && (
                <Button 
                  className="bg-red-600 hover:bg-red-700 shadow-lg shadow-red-900/20"
                  onClick={handleBulkSEO}
                >
                  <Sparkles size={18} className="mr-2" /> Iniciar SEO Inteligente
                </Button>
              )}
            </footer>
          </div>
        </div>
      )}

      {/* MODAL BULK CATEGORY */}
      {isBulkCategoryModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl flex flex-col">
            <header className="p-6 border-b border-slate-800 bg-slate-800/50">
               <h2 className="text-lg font-bold text-white">{bulkCategoryAction === 'add' ? 'Adicionar' : 'Remover'} Categoria</h2>
            </header>
            <div className="p-6 flex flex-col gap-4">
              <label className="text-xs font-bold text-slate-400">Selecione as Categorias</label>
              <div className="max-h-60 overflow-y-auto bg-slate-800 border border-slate-700 rounded-lg p-2 space-y-2">
                {groupedCategories.map((root: any) => (
                  <div key={root.id}>
                    <p className="text-[10px] font-black uppercase text-slate-500 bg-slate-900 p-1 mb-1">{root.name}</p>
                    {[root, ...root.allChildren].sort((a,b) => a.name.localeCompare(b.name)).map((c: any) => (
                       <label key={c.id} className="flex items-center gap-2 p-1.5 hover:bg-slate-700 rounded cursor-pointer">
                          <input 
                            type="checkbox" 
                            checked={bulkSelectedCategoryIds.includes(c.id)}
                            onChange={(e) => {
                               if (e.target.checked) setBulkSelectedCategoryIds([...bulkSelectedCategoryIds, c.id]);
                               else setBulkSelectedCategoryIds(bulkSelectedCategoryIds.filter(id => id !== c.id));
                            }}
                            className="accent-red-600"
                          />
                          <span className="text-xs text-slate-300">{c.name}</span>
                       </label>
                    ))}
                  </div>
                ))}
              </div>
            </div>
            <footer className="p-6 border-t border-slate-800 flex gap-3">
              <Button variant="outline" onClick={() => setIsBulkCategoryModalOpen(false)}>Cancelar</Button>
              <Button onClick={handleBulkCategory} disabled={isBulkRunning || bulkSelectedCategoryIds.length === 0}>
                {isBulkRunning ? 'Processando...' : 'Confirmar'}
              </Button>
            </footer>
          </div>
        </div>
      )}
    </div>
  );
}
